# -*- coding: utf-8 -*-
import sys
#WARNING this line is only for enabling tests to work withing a vscode immage based on the workdir of the image used for that
#this needs to be reviewed for a better solution
sys.path.append('/home/tango/skampi/post-deployment/')